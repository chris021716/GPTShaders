#version 120
// GPT Shaders v1.0 source file
// Replace or expand this file with your GLSL implementation.

void main() {
    gl_Position = ftransform();
}
