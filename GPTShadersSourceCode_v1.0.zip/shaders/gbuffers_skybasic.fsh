#version 120
// GPT Shaders v1.0 source file

void main() {
    gl_FragColor = vec4(1.0);
}
